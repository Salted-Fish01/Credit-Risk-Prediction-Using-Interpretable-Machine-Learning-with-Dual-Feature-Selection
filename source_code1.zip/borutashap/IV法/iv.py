# -*- coding: utf-8 -*-
"""
Created on Sun Aug 22 10:41:04 2021

@author: 86135

"""

import toad
from toad.plot import bin_plot
import pickle
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
import math
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score
from sklearn.model_selection  import cross_val_score
#import statsmodels.api as sm
#混淆矩阵计算
from sklearn import metrics
from sklearn.metrics import roc_curve, auc,roc_auc_score
from sklearn.metrics import precision_score
from sklearn.metrics import accuracy_score
from sklearn.metrics import recall_score
from sklearn.metrics import f1_score

#readFileName="data_ngboost_borutaShap.xlsx"
readFileName="filtered_data (1).xlsx"
#读取excel
data=pd.read_excel(readFileName)
x=data.loc[:,"近12个月列入失信被执行人次数":"资产总额"]
y=data["是否违约"]
print(x.columns)
X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.3, random_state=0)
data1=data.loc[:,"近12个月列入失信被执行人次数":"是否违约"]
#detection=toad.detect(X_train)
var_select=toad.quality(x, y,iv_only=True)
#var_select=toad.quality(data,'target')
var_select.to_excel("第二轮实验变量iv值.xlsx")

