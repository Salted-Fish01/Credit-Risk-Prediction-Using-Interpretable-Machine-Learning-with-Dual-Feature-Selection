import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.impute import SimpleImputer
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.ensemble import NGBClassifier
import matplotlib.pyplot as plt

# 读取 Excel 文件
data2 = pd.read_excel('data_boost_borutuShap.xlsx')

# 解决中文乱码问题
plt.rcParams['font.sans-serif'] = ['KaiTi']  # 指定默认字体
plt.rcParams['axes.unicode_minus'] = False  # 解决保存图像是负号'-'显示为方块的问题

# 指定特征和标签
X = data2.loc[:, "市":"总资产周转率"]
y = data2["是否违约"]

# 查看列名
print(data2.columns)

# 删除不需要的列
data2.drop('近60个月地址变更次数', axis=1, inplace=True, errors='ignore')

# 再次查看列名
print(data2.columns)

# 处理缺失值
imp = SimpleImputer(missing_values=np.nan, strategy='median')
imp.fit(X)
X_sim = imp.transform(X)

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X_sim, y, test_size=0.3, random_state=42)

# 将预测标签转换为 DataFrame
df_y_test = pd.DataFrame(y_test)
df_X_test = pd.DataFrame(X_test)

# 将测试集保存到 Excel 文件
df_test = pd.concat([df_X_test, df_y_test], axis=1)
df_test.to_excel("测试集.xlsx")

# 训练模型
ngb = NGBClassifier(Dist=Bernoulli, natural_gradient=False)
ngb.fit(X_train, y_train)

# 预测
y_pred = ngb.predict(X_test)
y_true = y_test
accuracyScore = accuracy_score(y_true, y_pred)
print("test data:")
print("model accuracy is:", accuracyScore)

precision = precision_score(y_true, y_pred)
print("model precision is:", precision)

sensitivity = recall_score(y_true, y_pred)
print("model sensitivity is:", sensitivity)

f1Score = f1_score(y_true, y_pred)
print("f1_score:", f1Score)