# -*- coding: utf-8 -*-
"""
Created on Sun Feb  2 09:23:03 2025

@author: Administrator
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from ngboost import NGBClassifier
from ngboost.distns import Bernoulli
from BorutaShap import BorutaShap

# 示例数据
np.random.seed(0)
data = pd.DataFrame({
    'x1': np.random.rand(100),
    'x2': np.random.rand(100),
    'x3': np.random.rand(100),
    'y': np.random.randint(0, 2, 100)
})

# 划分特征和目标变量
X = data[['x1', 'x2', 'x3']]
y = data['y']

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 初始化 NGBoost 模型
ngb_model = NGBClassifier(Dist=Bernoulli, n_estimators=100,  verbose=False)

# 初始化 BorutaShap
feature_selector = BorutaShap(model=ngb_model, importance_measure='shap', classification=True)

# 训练特征选择器
feature_selector.fit(X=X_train, y=y_train, n_trials=100, sample=False, train_or_test='test', normalize=True, verbose=True)

# 获取筛选后的特征
selected_features = X.columns[feature_selector.accepted].tolist()
print(f"Selected Features: {selected_features}")

# 可视化特征选择结果
feature_selector.plot(which_features='all')