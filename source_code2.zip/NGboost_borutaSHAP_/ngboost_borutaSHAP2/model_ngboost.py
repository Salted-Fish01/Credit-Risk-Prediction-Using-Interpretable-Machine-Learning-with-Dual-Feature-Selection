# -*- coding: utf-8 -*-
"""
最佳选择
imp = SimpleImputer(missing_values=np.nan, strategy='median')
test data:
model accuracy is: 0.9485387547649301
model precision is: 0.6538461538461539
model sensitivity is: 0.19101123595505617
f1_score: 0.29565217391304344
time consume: 0.071807861328125
AUC: 0.8396284946846745
good classifier
gini 0.679256989369349
ks value:0.5647

imp = SimpleImputer(missing_values=np.nan, strategy='mean')
test data:
model accuracy is: 0.9491740787801779
model precision is: 0.68
model sensitivity is: 0.19101123595505617
f1_score: 0.2982456140350877
time consume: 0.07579350471496582
AUC: 0.8373699542238868
good classifier
gini 0.6747399084477737
ks value:0.5480

imp = SimpleImputer(missing_values=np.nan, strategy='most_frequent')
test data:
model accuracy is: 0.9472681067344345
model precision is: 0.6153846153846154
model sensitivity is: 0.1797752808988764
f1_score: 0.2782608695652174
time consume: 0.0718076229095459
AUC: 0.8331857904891613
good classifier
gini 0.6663715809783226
ks value:0.5421
"""
from sklearn.impute import SimpleImputer
import time
# import packages
import pandas as pd
from ngboost import NGBClassifier
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn import model_selection
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score
#混淆矩阵计算
from sklearn import metrics
from sklearn.metrics import roc_curve, auc,roc_auc_score
from sklearn.metrics import precision_score
from sklearn.metrics import accuracy_score
from sklearn.metrics import recall_score
from sklearn.metrics import f1_score
#中文乱码问题
plt.rcParams['font.sans-serif'] = ['KaiTi'] # 指定默认字体
plt.rcParams['axes.unicode_minus'] = False # 解决保存图像是负号'-'显示为方块的问题
#读取训练数据
readFileName="data_ngboost_borutaShap.xlsx"

#读取excel
data=pd.read_excel(readFileName)
# 随机打乱数据
#data1 = data.sample(frac=1).reset_index(drop=True)  # frac=1表示打乱全部
X=data.loc[:,"市":"总资产周转率"]
y=data["是否违约"]

#缺失值填充
imp = SimpleImputer(missing_values=np.nan, strategy='median')
#imp = SimpleImputer(missing_values=np.nan, strategy='mean')
#imp = SimpleImputer(missing_values=np.nan, strategy='most_frequent')
imp.fit(X)
X1=imp.transform(X)
X_train, X_test, y_train, y_test=train_test_split(X1,y,test_size=0.3,random_state=42)

#Bernoulli is the default and is equivalent to k_categorical(2).
ngb = NGBClassifier(n_estimators=500,natural_gradient = False)
#natural_gradient=True效果不如natural_gradient = False
#ngb = NGBClassifier(n_estimators=500,natural_gradient=True)
ngb.fit(X_train,y_train)

y_pred = ngb.predict(X_test)
time1=time.time()

y_true=y_test
y_pred=ngb.predict(X_test)
accuracyScore = accuracy_score(y_true, y_pred)
print("test data:")
print('model accuracy is:',accuracyScore)

precision=precision_score(y_true, y_pred)
print('model precision is:',precision)

sensitivity=recall_score(y_true, y_pred)
print('model sensitivity is:',sensitivity)
 
f1Score=f1_score(y_true, y_pred)
print("f1_score:",f1Score)

time2=time.time()
time_consume=time2-time1
print("time consume:",time_consume)

probablity_list=ngb.predict_proba(X_test)
pos_probablity_list=[i[1] for i in probablity_list]

all_probablity_list=ngb.predict_proba(X1)
all_pos_probablity_list=[i[1] for i in all_probablity_list]
df_all=pd.DataFrame({'score':all_pos_probablity_list, 'target':y})
df_all.to_excel("all_score_target.xlsx")

def AUC(y_true, y_scores):
    auc_value=0
    fpr, tpr, thresholds = metrics.roc_curve(y_true, y_scores, pos_label=1)
    auc_value= auc(fpr,tpr) ###计算auc的值 
    if auc_value<0.5:
        auc_value=1-auc_value
    return auc_value

def Draw_roc(auc_value):
    fpr, tpr, thresholds = metrics.roc_curve(y_test, pos_probablity_list, pos_label=1)
    #画对角线 
    plt.plot([0, 1], [0, 1], '--', color=(0.6, 0.6, 0.6), label='Diagonal line') 
    plt.plot(fpr,tpr,label='ROC curve (area = %0.2f)' % auc_value) 
    plt.title('ngboost AUC curve')  
    plt.legend(loc="lower right")
    plt.savefig("ngboost AUC curve.png")

#评价AUC表现
def AUC_performance(AUC):
    if AUC >=0.7:
        print("good classifier")
    if 0.7>AUC>0.6:
        print("not very good classifier")
    if 0.6>=AUC>0.5:
        print("useless classifier")
    if 0.5>=AUC:
        print("bad classifier,with sorting problems")
        
#Gini
def Gini(auc):
    gini=2*auc-1
    return gini

### 计算KS值
def KS(df, thescore, target):
    total = df.groupby([thescore])[target].count()
    bad = df.groupby([thescore])[target].sum()
    all = pd.DataFrame({'total':total, 'bad':bad})
    all['good'] = all['total'] - all['bad']
    all[thescore] = all.index
    all.index = range(len(all))
    all = all.sort_values(by=thescore,ascending=True)
    #坏客户总数
    num_bad=all['bad'].sum()
    #好客户总数
    num_good= all['good'].sum()
    #累计坏客户概率
    all['badCumRate'] = all['bad'].cumsum() / num_bad
    #累计好客户概率
    all['goodCumRate'] = all['good'].cumsum() /num_good
    #坏客户-好客户概率的序列
    ks_array = all.apply(lambda x: abs(x.badCumRate - x.goodCumRate), axis=1)
    #坏客户-好客户概率的序列的最大值就是ks值
    ks=max(ks_array)
    return ks
        
#绘制ks
def Draw_KS6(fpr, tpr, ks_array,ks):  
    plt.figure(figsize=(15,10))
    plt.style.use('ggplot')
    #plt.style.use('dark_background')
    #绘制tpr,即累计好客户概率曲线
    plt.plot(tpr,label='tpr')  
    #绘制fpr,即累计坏客户概率曲线
    plt.plot(fpr,label='fpr') 
    #绘制ks曲线，即tpr-fpr
    plt.plot(ks_array,label='ks_array') 
    plt.legend(loc="lower right")
    plt.title('ngboost KS curve')
    plt.xlabel("model score range")
    plt.ylabel("values")
    plt.savefig("ngboost KS curve.png")
    #输出图片
    plt.show()
    
#Auc验证，数据采用测试集数据
auc_value=AUC(y_test, pos_probablity_list)
print("AUC:",auc_value)
#评价AUC表现
AUC_performance(auc_value)
#绘制ROC曲线
Draw_roc(auc_value)

df=pd.DataFrame({'score':pos_probablity_list, 'target':y_test})
df.to_excel("score_target.xlsx")
#基尼系数
gini=Gini(auc_value)
print ("gini",gini)  
 
#计算KS
ks = KS(df,'score','target')
print("ks value:%.4f"%ks)
#绘制ks
target=df["target"]
score=df["score"]
fpr, tpr, thresholds = roc_curve(target, score, pos_label=1)
ks_array=tpr-fpr
Draw_KS6(fpr, tpr, ks_array,ks)

#保存模型验证结果
result={'模型':['ngboost'],'Accuracy':[accuracyScore],'Precision':[precision],'Sensitivity':[sensitivity],
        'F1_score':[f1Score],"AUC":[auc_value],'Gini':[gini],"KS":[ks]}
df_performance=pd.DataFrame(result)
df_performance.to_excel("ngboost模型验证结果.xlsx")

#变量重要性
feature_importances=ngb.feature_importances_
names=list(X.columns)
#list_feature_importances=list(zip(feature_importances,names))
#df_feature_importances=pd.DataFrame(list_feature_importances)

# 将特征重要性与特征名称结合，创建DataFrame
importances_df = pd.DataFrame({'feature': names, 'importance': feature_importances[0]})

# 对特征重要性进行排序
importances_df1 = importances_df.sort_values(by='importance', ascending=False)

# 打印特征重要性
print(importances_df1)
importances_df1.to_excel("ngboost_变量重要性.xlsx")


